using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    [SerializeField] private TMP_Text diamondText;
    [SerializeField] private Image[] images;

    void Start()
    {

    }

    public void UpdateDiamond(int diamond)
    {
        diamondText.text = diamond.ToString();
    }
}
